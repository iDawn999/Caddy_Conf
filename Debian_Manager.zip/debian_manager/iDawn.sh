
#!/usr/bin/env bash
# ============================================================
# iDawn 管理平台 - 框架完成版（功能占位，输出系统重构）
# ============================================================

# ------------------------------------------------------------
# ① 脚本真实路径
# ------------------------------------------------------------
SCRIPT_PATH="$(readlink -f "${BASH_SOURCE[0]}")"
SCRIPT_DIR="$(dirname "$SCRIPT_PATH")"

readonly IDAWN_ROOT="$SCRIPT_DIR"
readonly CONFIG_FILE="$IDAWN_ROOT/config.conf"

# ------------------------------------------------------------
# ② 安全启动
# ------------------------------------------------------------
set -Eeuo pipefail

trap 'printf "\n❌ 脚本在第 %s 行执行失败：%s\n" "$LINENO" "$BASH_COMMAND" >&2' ERR

# ------------------------------------------------------------
# ③ 加载配置
# ------------------------------------------------------------
if [[ ! -f "$CONFIG_FILE" ]]; then
    printf "❌ 配置文件不存在：%s\n" "$CONFIG_FILE" >&2
    exit 1
fi

set +eu
source "$CONFIG_FILE"
set -eu

# ------------------------------------------------------------
# ④ 关键变量校验
# ------------------------------------------------------------
require_var() {
    local name="$1"
    local value

    set +u
    if ! declare -p "$name" &>/dev/null; then
        set -u
        printf "❌ 必需变量未定义：%s\n" "$name" >&2
        exit 1
    fi
    value="${!name}"
    set -u

    if [[ -z "$value" ]]; then
        printf "❌ 必需变量为空：%s\n" "$name" >&2
        exit 1
    fi
}

require_var SITE_DIR
require_var TEMPLATE_DIR
require_var CADDY_CONF_DIR
require_var TEMP_DIR

# ------------------------------------------------------------
# ⑤ TTY 与 UTF-8 检测
# ------------------------------------------------------------
_IDAWN_TTY_=false
_IDAWN_UTF8_=false

[[ -t 1 ]] && _IDAWN_TTY_=true
if locale 2>/dev/null | grep -qi 'utf-8'; then
    _IDAWN_UTF8_=true
fi

# ------------------------------------------------------------
# ⑥ 颜色与样式
# ------------------------------------------------------------
COLOR_RED='\033[0;31m'
COLOR_GREEN='\033[0;32m'
COLOR_YELLOW='\033[0;33m'
COLOR_BLUE='\033[0;34m'
COLOR_CYAN='\033[0;36m'
COLOR_GRAY='\033[0;90m'
STYLE_BOLD='\033[1m'
RESET='\033[0m'

# ------------------------------------------------------------
# ⑦ 图标（自动降级）
# ------------------------------------------------------------
if $_IDAWN_UTF8_; then
    ICON_INFO="ℹ️"
    ICON_SUCCESS="✅"
    ICON_WARNING="⚠️"
    ICON_ERROR="❌"
    ICON_STEP="➜"
else
    ICON_INFO="[INFO]"
    ICON_SUCCESS="[OK]"
    ICON_WARNING="[WARN]"
    ICON_ERROR="[ERR]"
    ICON_STEP=">>"
fi

# ------------------------------------------------------------
# ⑧ 核心输出函数
# ------------------------------------------------------------
_strip_color() {
    sed 's/\x1b\[[0-9;]*m//g'
}

__out() {
    local fd="$1"
    local text="$2"
    if $_IDAWN_TTY_; then
        printf "%b\n" "$text" >&"$fd"
    else
        printf "%s\n" "$(printf "%b" "$text" | _strip_color)" >&"$fd"
    fi
}

print()   { __out 1 "$*${RESET}"; }
info()    { __out 1 "${COLOR_BLUE}${ICON_INFO} $*${RESET}"; }
step()    { __out 1 "${COLOR_CYAN}${ICON_STEP} $*${RESET}"; }
success() { __out 1 "${COLOR_GREEN}${ICON_SUCCESS} $*${RESET}"; }
warning() { __out 2 "${COLOR_YELLOW}${ICON_WARNING} $*${RESET}"; }
error()   { __out 2 "${COLOR_RED}${ICON_ERROR} $*${RESET}"; }
fatal()   { __out 2 "${COLOR_RED}${ICON_ERROR} $*${RESET}"; exit 1; }

# ------------------------------------------------------------
# ⑨ UI 工具
# ------------------------------------------------------------
clear_screen() { clear || true; }

pause() {
    print "${COLOR_GRAY}按任意键继续...${RESET}"
    read -n 1 || true
}

title() {
    local text="$1"
    local width=60
    printf "%b\n" "${COLOR_CYAN}${STYLE_BOLD}"
    printf "%*s\n" "$width" "" | tr ' ' '='
    printf "%*s%s\n" $(((width-${#text})/2)) "" "$text"
    printf "%*s%b\n" "$width" "" "${RESET}" | tr ' ' '='
}

separator() {
    printf "%*s\n" 60 "" | tr ' ' '-'
}

# ------------------------------------------------------------
# ⑩ 输入函数（稳定）
# ------------------------------------------------------------
input() {
    local prompt="$1"
    local value

    if $_IDAWN_TTY_; then
        printf "%b" "${COLOR_CYAN}${prompt}${RESET} " >&2
    fi

    IFS= read -r value || value=""
    value="${value//$'\r'/}"
    value="${value#"${value%%[![:space:]]*}"}"
    value="${value%"${value##*[![:space:]]}"}"
    printf "%s" "$value"
}

# ------------------------------------------------------------
# 中间件管理
# ------------------------------------------------------------
install_caddy() {
    clear_screen
    title "安装 Caddy Web 服务器"
    separator

    if command -v caddy >/dev/null 2>&1; then
        success "检测到 Caddy 已安装"
        systemctl is-active --quiet caddy && info "Caddy 服务正在运行"
        pause
        return
    fi

    [[ $EUID -eq 0 ]] || { error "需要 root 权限"; pause; return; }
    command -v apt-get >/dev/null || { error "仅支持 Debian/Ubuntu"; pause; return; }

    step "开始安装 Caddy..."

    apt-get update -y >/dev/null 2>&1
    apt-get install -y curl gpg apt-transport-https >/dev/null 2>&1

    [[ -f /usr/share/keyrings/caddy-stable-archive-keyring.gpg ]] || \
        curl -fsSL https://dl.cloudsmith.io/public/caddy/stable/gpg.key \
        | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg

    [[ -f /etc/apt-get/sources.list.d/caddy-stable.list ]] || \
        curl -fsSL https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt \
        | tee /etc/apt/sources.list.d/caddy-stable.list >/dev/null

    apt-get update -y >/dev/null
    apt-get install -y caddy >/dev/null

    step "创建必要目录..."
    mkdir -p "$SITE_DIR" "$TEMPLATE_DIR" "$CADDY_CONF_DIR"

    step "设置目录权限..."
    chown -R caddy:caddy "$SITE_DIR" "$TEMPLATE_DIR" "$CADDY_CONF_DIR"
    chmod -R 755 "$SITE_DIR" "$TEMPLATE_DIR" "$CADDY_CONF_DIR"

    step "删除默认 Caddyfile..."
    rm -f "$CADDY_FILE"

    step "下载 Caddyfile 配置文件..."
    wget -O "$CADDY_FILE" https://raw.githubusercontent.com/iDawn999/Caddy_Conf/refs/heads/main/Caddyfile >/dev/null 2>&1

    step "设置 Caddyfile 权限..."
    chown caddy:caddy "$CADDY_FILE"
    chmod 644 "$CADDY_FILE"

    step "下载静态站点配置文件..."
    wget -O "$TEMPLATE_DIR/static_site.conf" https://raw.githubusercontent.com/iDawn999/Caddy_Conf/refs/heads/main/static_site.conf >/dev/null 2>&1
    
    step "下载反向代理配置文件..."
    wget -O "$TEMPLATE_DIR/reverse_proxy.conf" https://raw.githubusercontent.com/iDawn999/Caddy_Conf/refs/heads/main/reverse_proxy.conf >/dev/null 2>&1

    step "设置 Caddy 服务..."
    systemctl enable --now caddy >/dev/null
    success "Caddy 安装完成"
    pause
}

install_docker() {
    clear_screen
    title "安装 Docker"
    separator

    if command -v docker >/dev/null 2>&1; then
        success "检测到 Docker 已安装"
        pause
        return
    fi

    [[ $EUID -eq 0 ]] || { error "需要 root 权限"; pause; return; }

    mkdir -p "$TEMP_DIR/docker"
    cd "$TEMP_DIR/docker"
    curl -fsSL https://get.docker.com -o install.sh
    sh install.sh >/dev/null
    cd / && rm -rf "$TEMP_DIR/docker"

    systemctl enable --now docker >/dev/null
    success "Docker 安装完成"
    pause
}

install_acme() {
    clear_screen
    title "安装 ACME"
    separator

    if command -v acme.sh >/dev/null 2>&1; then
        success "检测到 ACME 已安装"
        pause
        return
    fi

    [[ $EUID -eq 0 ]] || { error "需要 root 权限"; pause; return; }

    step "开始安装 ACME..."
    curl https://get.acme.sh | sh -s email=livingalone9999@qq.com

    success "ACME 安装完成"
    pause
}

# =========================================================
# 站点管理
# =========================================================
add_static() {
    local domain
    domain="$(input "请输入站点域名")"
    [[ -z "$domain" ]] && { error "域名不能为空"; pause; return; }

    step "创建站点目录..."
    mkdir -p "$SITE_DIR/$domain"
    chown -R caddy:caddy "$SITE_DIR/$domain"

    step "创建站点配置文件..."
    cp "$TEMPLATE_DIR/static_site.conf" "$CADDY_CONF_DIR/$domain.conf" 
    sed -i "s/example.com/$domain/g" "$CADDY_CONF_DIR/$domain.conf"

    step "设置站点配置文件权限..."
    chown -R caddy:caddy "$SITE_DIR/$domain" "$CADDY_CONF_DIR/$domain.conf"
    chmod -R 755 "$SITE_DIR/$domain" "$CADDY_CONF_DIR/$domain.conf"

    step "重新启动 Caddy ..."
    systemctl restart caddy

    success "静态站点 $domain 创建完成"
    pause
}

add_reverse_proxy() {
    local domain addr port target

    domain="$(input "请输入站点域名")"
    [[ -z "$domain" ]] && { error "域名不能为空"; pause; return; }

    addr="$(input "反代地址（默认 127.0.0.1）")"
    port="$(input "反代端口（默认 8080）")"

    addr="${addr:-127.0.0.1}"
    port="${port:-8080}"
    target="http://$addr:$port"

    step "创建站点配置文件..."
    cp "$TEMPLATE_DIR/reverse_proxy.conf" "$CADDY_CONF_DIR/$domain.conf"
    sed -i "s/example.com/$domain/g" "$CADDY_CONF_DIR/$domain.conf"
    sed -i "s|http://localhost:8080|$target|g" "$CADDY_CONF_DIR/$domain.conf"

    step "设置配置文件权限..."
    chown caddy:caddy "$CADDY_CONF_DIR/$domain.conf"
    chmod 644 "$CADDY_CONF_DIR/$domain.conf"

    step "重新启动 Caddy ..."
    systemctl restart caddy

    success "反向代理站点 $domain 创建完成"
    pause
}

del_site() {
    local domain
    domain="$(input "请输入要删除的站点域名")"
    [[ -z "$domain" ]] && { error "域名不能为空"; pause; return; }

    step "删除站点目录..."
    rm -rf "$SITE_DIR/$domain" >/dev/null 2>&1

    step "删除站点配置文件..."
    rm -f "$CADDY_CONF_DIR/$domain.conf" >/dev/null 2>&1

    step "重新启动 Caddy ..."
    systemctl restart caddy >/dev/null 2>&1

    success "站点 $domain 删除完成"
    pause
}

# ============================================================
# 菜单系统
# ============================================================

middle_manager() {
    while true; do
        clear_screen
        title "中间件管理"
        separator
        echo "1. 安装 Caddy"
        echo "2. 安装 Docker"
        echo "3. 安装 ACME"
        echo "0. 返回"
        case "$(input "请选择")" in
            1) install_caddy ;;
            2) install_docker ;;
            3) install_acme ;;
            0) return ;;
            *) warning "无效选项"; pause ;;
        esac
    done
}

website_manager() {
    while true; do
        clear_screen
        title "站点管理"
        separator
        echo "1. 添加静态站点"
        echo "2. 添加反向代理"
        echo "3. 删除站点"
        separator
        echo "0. 返回"
        case "$(input "请选择")" in
            1) add_static ;;
            2) add_reverse_proxy ;;
            3) del_site ;;
            0) return ;;
            *) warning "无效选项"; pause ;;
        esac
    done
}

system_manager() {
    while true; do
        clear_screen
        title "系统配置"
        separator
        echo "1. 查看配置"
        echo "2. 编辑配置"
        echo "0. 返回"
        case "$(input "请选择")" in
            1) not_implemented ;;
            2) not_implemented ;;
            0) return ;;
            *) warning "无效选项"; pause ;;
        esac
    done
}

main_menu() {
    while true; do
        clear_screen
        title "iDawn 主菜单"
        separator
        echo "1. 系统配置"
        echo "2. 中间件管理"
        echo "3. 站点管理"
        echo "99. 退出"
        case "$(input "请选择")" in
            1) system_manager ;;
            2) middle_manager ;;
            3) website_manager ;;
            99) success "已退出"; exit 0 ;;
            *) warning "无效选项"; pause ;;
        esac
    done
}

# ------------------------------------------------------------
# 启动入口
# ------------------------------------------------------------
main_menu
